<?php 

$mysqli = new mysqli("localhost", "root", "", "supersuit");

$mysqli->set_charset("utf8mb4");