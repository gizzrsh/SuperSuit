    </main>
    <footer class="footer">
        <div class="container footer__container">
            <a href="index.php" class="footer__logo">Super<span>Suit</span></a>
            <a href="tel:+375293512740" class="footer__phone">+375 29 351-27-40</a>
        </div>
    </footer>
    <script type="module" src="js/script.js"></script>
</body>
</html>